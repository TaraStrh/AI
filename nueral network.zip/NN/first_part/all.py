import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt

def train_and_test_model(x, function):
    # Create DataFrame
    data = pd.DataFrame({'x': x, 'y': function})

    # train and test split
    train, test = train_test_split(data, test_size=0.2, random_state=0)

    #devide to x and y for test and train
    x_train = train['x'].values.reshape(-1,1)
    y_train = train['y'].values.reshape(-1,1)
    x_test = test['x'].values.reshape(-1,1)
    y_test = test['y'].values.reshape(-1,1)

    # Train the MLPRegressor model
    mlp = MLPRegressor(random_state=1, max_iter=500).fit(x_train, y_train.ravel())

    # Predict on training and test set
    pred_train = mlp.predict(x_train)
    pred_test = mlp.predict(x_test)

    # Calculate mean squared error
    error_train = mean_squared_error(y_train,pred_train)
    error_test = mean_squared_error(y_test,pred_test)
    print("Error of train:", error_train)
    print("Error of test:", error_test)

    # Plot real vs predicted for training set
    plt.figure(figsize=(10, 6))
    plt.scatter(x_train, y_train, color='blue', label='Real')
    plt.scatter(x_train, pred_train, color='red', label='Predicted')
    plt.title('Real vs Predicted (Training Set)')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.legend()
    plt.show()

    # Plot real vs predicted for test set
    plt.figure(figsize=(10, 6))
    plt.scatter(x_test, y_test, color='blue', label='Real')
    plt.scatter(x_test, pred_test, color='red', label='Predicted')
    plt.title('Real vs Predicted (Test Set)')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.legend()
    plt.show()

# Generate data and call the function for each case
x1 = np.linspace(0, 2, 1000)
function1 = x1 * np.cos(x1)
train_and_test_model(x1, function1)

x2 = np.linspace(0.1, 2, 1000)
function2 = np.log2(x2)
train_and_test_model(x2, function2)

x3 = np.linspace(0, 2, 1000)
function3 = x3**x3 * np.sin(x3)
train_and_test_model(x3, function3)
