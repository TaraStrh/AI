import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt

# Generate data
x = np.linspace(0, 2, 1000)
function = x**x * np.sin(x)

# Create DataFrame
data = pd.DataFrame({'x': x, 'y': function})

# train and test split
train, test = train_test_split(data,test_size=0.2 , random_state=0)

#devide to x and y for test and train
x_train = train['x'].values.reshape(-1,1)
y_train = train['y'].values.reshape(-1,1)
x_test = test['x'].values.reshape(-1,1)
y_test = test['y'].values.reshape(-1,1)

mlp = MLPRegressor(random_state=1, max_iter=500).fit(x_train, y_train.ravel())

pred_train= mlp.predict(x_train)
pred_test = mlp.predict(x_test)

error_train = mean_squared_error(y_train,pred_train)
error_test = mean_squared_error(y_test,pred_test)
print("error of train" , error_train)
print("error of test" , error_test)

# Plot real vs predicted for training set
plt.figure(figsize=(10, 6))
plt.scatter(x_train, y_train, color='blue', label='Real')
plt.scatter(x_train, pred_train, color='red', label='Predicted')
plt.title('Real vs Predicted (Training Set)')
plt.xlabel('x')
plt.ylabel('y')
plt.legend()
plt.show()

# Plot real vs predicted for test set
plt.figure(figsize=(10, 6))
plt.scatter(x_test, y_test, color='blue', label='Real')
plt.scatter(x_test, pred_test, color='red', label='Predicted')
plt.title('Real vs Predicted (Test Set)')
plt.xlabel('x')
plt.ylabel('y')
plt.legend()
plt.show()
