import pandas as pd
import numpy as np
from sklearn.neural_network import MLPRegressor
import matplotlib.pyplot as plt
train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')
x_train = train.drop(columns=['y']) 
y_train = train['y']
x_test = test.drop(columns=['y'])
y_test = test['y']
mlp = MLPRegressor(random_state=42 , max_iter=10000).fit(x_train, y_train.values.ravel())
predict_y = mlp.predict(x_test)
plt.plot(x_train, y_train, 'o', label="training data")
plt.plot(x_test, y_test, 'o', label="test data")
plt.plot(x_test, predict_y, 'o', label="predicted data")

plt.legend()
plt.xlabel("x")
plt.ylabel("y")
plt.show()

